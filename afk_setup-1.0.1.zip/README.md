This is an afk setup for minecraft created by rayane866

F6: start/stop killing
F7: start/stop fishing/placing block
F8: start/stop breaking blocks
F12: exit